﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Gurock.TestRail.dll")]
[assembly: AssemblyCompany("Gurock Software GmbH")]
[assembly: AssemblyProduct("TestRail API Binding (API v2)")]
[assembly: AssemblyCopyright("Copyright (C) Gurock Software GmbH")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
